# Pipol App

A mobile application designed to reconnect people in real life through physical events displayed on an interactive map.

## Getting Started

### Prerequisites

- Node.js (v16 or later)
- npm or yarn
- Expo Go app on your mobile device

### Installation

1. Clone this repository to your local machine
2. Navigate to the project directory:
   ```
   cd pipol-app
   ```
3. Install dependencies:
   ```
   npm install
   ```
   
### Running the App

1. Start the development server:
   ```
   npx expo start
   ```
2. Scan the QR code with your iPhone camera or Expo Go app
3. The app will open in Expo Go on your device

## Features

- Interactive map displaying nearby events
- Create and manage your own events
- User profiles and authentication
- Real-time updates with WebSockets

## Login Credentials

For testing purposes, you can use:
- Email: test@example.com
- Password: testpassword

## Database Schema

The app uses a PostgreSQL database with the following structure:
- users: User profiles and authentication
- events: Event details and location information
- event_attendees: Tracks event participation
- user_interests: User preferences for event categories

## Technologies Used

- React Native / Expo
- TypeScript
- PostgreSQL
- Express.js backend
- Mapbox / React Native Maps
- Stripe for payments