import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Supabase credentials
// Note: In a production app, you should use environment variables
const supabaseUrl = 'https://pbvkjkjdtwftjetpreai.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBidmtqa2pkdHdmdGpldHByZWFpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg4MTY3NjksImV4cCI6MjA1NDM5Mjc2OX0.tghHK22x2VJILMiQi56UCqaGfVc0PF0so_cKHXufibs';

// Create a single supabase client for interacting with your database
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage as any,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Type definitions for database tables
export type User = {
  id: string;
  created_at: string;
  email: string;
  username: string;
  name: string;
  bio: string | null;
  avatar_url: string | null;
};

export type Event = {
  id: string;
  created_at: string;
  user_id: string;
  title: string;
  description: string;
  category: string;
  price: number;
  date_time: string;
  latitude: number;
  longitude: number;
  location_name: string;
  location_address: string | null;
  privacy_type: 'public' | 'private';
  payment_type: 'free' | 'paid';
  max_capacity: number | null;
  photo_url: string | null;
};

export type EventAttendee = {
  id: string;
  created_at: string;
  event_id: string;
  user_id: string;
  status: 'pending' | 'approved' | 'rejected';
  payment_status: string | null;
  payment_intent_id: string | null;
};

// Authentication functions
export const signUp = async (email: string, password: string, username: string, name: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        username,
        name,
      },
    },
  });

  if (error) throw error;
  return data;
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getCurrentUser = async () => {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  
  if (data?.user) {
    const { data: profileData, error: profileError } = await supabase
      .from('users')
      .select('*')
      .eq('id', data.user.id)
      .single();

    if (profileError) throw profileError;
    return profileData;
  }
  
  return null;
};

// Event functions
export const getEvents = async (category?: string, distance?: number, dateFrom?: string, dateTo?: string) => {
  let query = supabase
    .from('events')
    .select('*')
    .eq('privacy_type', 'public');

  if (category) {
    query = query.eq('category', category);
  }

  if (dateFrom) {
    query = query.gte('date_time', dateFrom);
  }

  if (dateTo) {
    query = query.lte('date_time', dateTo);
  }

  // Note: Distance filtering would typically be done with PostGIS on the backend
  // For a simple version, we can filter by distance on the client side after fetching

  const { data, error } = await query;
  if (error) throw error;
  return data;
};

export const getNearbyEvents = async (latitude: number, longitude: number, radiusInKm: number = 5) => {
  // Get all public events
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('privacy_type', 'public');

  if (error) throw error;

  // Filter by distance on the client side
  // This is not efficient for large datasets, but works for demonstration
  if (data) {
    return data.filter(event => {
      const distance = calculateDistance(
        latitude, 
        longitude, 
        event.latitude, 
        event.longitude
      );
      return distance <= radiusInKm;
    });
  }

  return [];
};

// Helper function to calculate distance between two coordinates in kilometers
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  return distance;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

export const createEvent = async (eventData: Omit<Event, 'id' | 'created_at' | 'user_id'>) => {
  const user = await supabase.auth.getUser();
  if (!user.data?.user) throw new Error('User not authenticated');

  const { data, error } = await supabase
    .from('events')
    .insert({
      ...eventData,
      user_id: user.data.user.id,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getEventById = async (id: string) => {
  const { data, error } = await supabase
    .from('events')
    .select('*, users(*)')
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
};

export const joinEvent = async (eventId: string) => {
  const user = await supabase.auth.getUser();
  if (!user.data?.user) throw new Error('User not authenticated');

  const { data, error } = await supabase
    .from('event_attendees')
    .insert({
      event_id: eventId,
      user_id: user.data.user.id,
      status: 'approved', // Auto-approve for now
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const leaveEvent = async (eventId: string) => {
  const user = await supabase.auth.getUser();
  if (!user.data?.user) throw new Error('User not authenticated');

  const { error } = await supabase
    .from('event_attendees')
    .delete()
    .match({ event_id: eventId, user_id: user.data.user.id });

  if (error) throw error;
  return true;
};

export const getUserCreatedEvents = async () => {
  const user = await supabase.auth.getUser();
  if (!user.data?.user) throw new Error('User not authenticated');

  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('user_id', user.data.user.id);

  if (error) throw error;
  return data;
};

export const getUserAttendingEvents = async () => {
  const user = await supabase.auth.getUser();
  if (!user.data?.user) throw new Error('User not authenticated');

  const { data, error } = await supabase
    .from('event_attendees')
    .select('*, events(*)')
    .eq('user_id', user.data.user.id)
    .eq('status', 'approved');

  if (error) throw error;
  
  // Extract the events from the nested structure
  return data.map(attendee => attendee.events);
};

// User profile functions
export const updateUserProfile = async (userData: Partial<User>) => {
  const user = await supabase.auth.getUser();
  if (!user.data?.user) throw new Error('User not authenticated');

  const { data, error } = await supabase
    .from('users')
    .update(userData)
    .eq('id', user.data.user.id)
    .select()
    .single();

  if (error) throw error;
  return data;
};