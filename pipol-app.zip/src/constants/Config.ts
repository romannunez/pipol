// API Configuration
export const API_URL = 'http://localhost:5000';

// Map Configuration
export const MAP_INITIAL_REGION = {
  latitude: 37.78825,
  longitude: -122.4324,
  latitudeDelta: 0.0922,
  longitudeDelta: 0.0421,
};

// Event Categories
export const EVENT_CATEGORIES = [
  'Social',
  'Sports',
  'Education',
  'Technology',
  'Arts',
  'Music',
  'Food',
  'Fitness',
  'Environment',
  'Business',
  'Other',
];

// Payment Types
export const PAYMENT_TYPES = ['Free', 'Paid'];

// Server and API Keys
export const GOOGLE_MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY';