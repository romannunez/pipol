import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, TouchableOpacity, Text, Alert, ActivityIndicator } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/RootNavigator';
import { Ionicons } from '@expo/vector-icons';
import { API_URL } from '../constants/Config';

// Event type definition
type Event = {
  id: string;
  title: string;
  description: string;
  category: string;
  price: number;
  latitude: number;
  longitude: number;
  date_time: string;
};

type MapScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Main'>;

const MapScreen = () => {
  const navigation = useNavigation<MapScreenNavigationProp>();
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch user location
  useEffect(() => {
    (async () => {
      try {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          setErrorMsg('Permission to access location was denied');
          return;
        }

        let location = await Location.getCurrentPositionAsync({});
        setLocation(location);
        
        // Fetch events near this location
        fetchNearbyEvents(location.coords.latitude, location.coords.longitude);
      } catch (error) {
        console.error('Error getting location:', error);
        setErrorMsg('Failed to get your location. Please try again.');
        setLoading(false);
      }
    })();
  }, []);
  
  // Refresh events when the screen comes into focus
  useFocusEffect(
    useCallback(() => {
      if (location) {
        fetchNearbyEvents(location.coords.latitude, location.coords.longitude);
      }
      return () => {};
    }, [location])
  );
  
  // Function to fetch nearby events
  const fetchNearbyEvents = async (lat: number, lng: number) => {
    try {
      setLoading(true);
      
      // In a real app, this would be an actual API call
      // const response = await fetch(`${API_URL}/api/events?lat=${lat}&lng=${lng}&radius=10`);
      // if (!response.ok) throw new Error('Failed to fetch events');
      // const data = await response.json();
      // setEvents(data);
      
      // For now, simulate API response with sample data
      // but positioned relative to the user's current location
      const sampleData = [
        {
          id: '1',
          title: 'Beach Cleanup',
          description: 'Join us in cleaning up the beach',
          category: 'Environment',
          price: 0,
          latitude: lat + 0.01,
          longitude: lng + 0.01,
          date_time: new Date().toISOString(),
        },
        {
          id: '2',
          title: 'Yoga in the Park',
          description: 'Morning yoga session for all levels',
          category: 'Fitness',
          price: 5,
          latitude: lat - 0.01,
          longitude: lng - 0.005,
          date_time: new Date().toISOString(),
        },
        {
          id: '3',
          title: 'Tech Meetup',
          description: 'Networking event for tech professionals',
          category: 'Technology',
          price: 0,
          latitude: lat + 0.005,
          longitude: lng - 0.01,
          date_time: new Date().toISOString(),
        },
      ];
      
      // Simulate network delay
      setTimeout(() => {
        setEvents(sampleData);
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error fetching events:', error);
      Alert.alert('Error', 'Failed to fetch nearby events. Please try again.');
      setLoading(false);
    }
  };

  const handleMapLongPress = (event: any) => {
    const { coordinate } = event.nativeEvent;
    setSelectedLocation(coordinate);
    navigation.navigate('CreateEvent', {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    });
  };

  const handleMarkerPress = (eventId: string) => {
    navigation.navigate('EventDetail', { eventId });
  };

  const initialRegion = location
    ? {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      }
    : {
        latitude: 37.78825,
        longitude: -122.4324,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      };

  return (
    <View style={styles.container}>
      {errorMsg ? (
        <Text style={styles.errorText}>{errorMsg}</Text>
      ) : (
        <>
          <MapView
            style={styles.map}
            provider={PROVIDER_GOOGLE}
            initialRegion={initialRegion}
            showsUserLocation
            showsMyLocationButton
            onLongPress={handleMapLongPress}
          >
            {events.map((event) => (
              <Marker
                key={event.id}
                coordinate={{
                  latitude: event.latitude,
                  longitude: event.longitude,
                }}
                title={event.title}
                description={event.description}
                onPress={() => handleMarkerPress(event.id)}
              />
            ))}
          </MapView>

          {loading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#6200ee" />
              <Text style={styles.loadingText}>Loading nearby events...</Text>
            </View>
          )}

          <TouchableOpacity
            style={styles.createButton}
            onPress={() => navigation.navigate('CreateEvent', {})}
          >
            <Ionicons name="add" size={32} color="white" />
          </TouchableOpacity>
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  errorText: {
    fontSize: 16,
    color: 'red',
    textAlign: 'center',
    padding: 20,
  },
  loadingContainer: {
    position: 'absolute',
    top: 10,
    alignSelf: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  loadingText: {
    marginLeft: 10,
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  createButton: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    backgroundColor: '#6200ee',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
});

export default MapScreen;