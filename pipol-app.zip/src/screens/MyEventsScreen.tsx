import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/RootNavigator';
import { FontAwesome } from '@expo/vector-icons';

type MyEventsNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Main'>;

// Sample event data (in a real app, this would come from a database)
const sampleEvents = [
  {
    id: '1',
    title: 'Beach Cleanup',
    description: 'Join us in cleaning up the beach',
    category: 'Environment',
    price: 0,
    date_time: '2025-05-15T10:00:00Z',
    isOrganizer: false,
  },
  {
    id: '3',
    title: 'Javascript Workshop',
    description: 'Learn modern JavaScript with hands-on exercises',
    category: 'Education',
    price: 10,
    date_time: '2025-05-22T18:00:00Z',
    isOrganizer: true,
  },
];

const MyEventsScreen = () => {
  const navigation = useNavigation<MyEventsNavigationProp>();
  const [activeTab, setActiveTab] = useState('attending'); // 'attending' or 'organizing'

  // Filter events based on active tab
  const filteredEvents = sampleEvents.filter(event => 
    activeTab === 'attending' ? !event.isOrganizer : event.isOrganizer
  );

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const renderEventCard = ({ item }: { item: typeof sampleEvents[0] }) => (
    <TouchableOpacity
      style={styles.eventCard}
      onPress={() => navigation.navigate('EventDetail', { eventId: item.id })}
    >
      <View style={styles.cardHeader}>
        <Text style={styles.eventTitle}>{item.title}</Text>
        <View style={[styles.categoryBadge, getCategoryColor(item.category)]}>
          <Text style={styles.categoryText}>{item.category}</Text>
        </View>
      </View>

      <Text style={styles.eventDescription} numberOfLines={2}>
        {item.description}
      </Text>

      <View style={styles.eventFooter}>
        <View style={styles.eventInfo}>
          <FontAwesome name="calendar" size={14} color="#666" style={styles.icon} />
          <Text style={styles.eventInfoText}>{formatDate(item.date_time)}</Text>
        </View>

        <View style={styles.eventInfo}>
          <FontAwesome name="money" size={14} color="#666" style={styles.icon} />
          <Text style={styles.eventInfoText}>
            {item.price === 0 ? 'Free' : `$${item.price}`}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const getCategoryColor = (category: string) => {
    const colors: Record<string, object> = {
      'Social': { backgroundColor: '#FFD166' },
      'Sports': { backgroundColor: '#06D6A0' },
      'Education': { backgroundColor: '#118AB2' },
      'Technology': { backgroundColor: '#073B4C' },
      'Arts': { backgroundColor: '#EF476F' },
      'Music': { backgroundColor: '#B39CD0' },
      'Food': { backgroundColor: '#FF9E00' },
      'Fitness': { backgroundColor: '#5DD39E' },
      'Environment': { backgroundColor: '#81B29A' },
      'Business': { backgroundColor: '#414770' },
      'Other': { backgroundColor: '#89A2B8' },
    };
    
    return colors[category] || { backgroundColor: '#89A2B8' };
  };

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'attending' && styles.activeTab]}
          onPress={() => setActiveTab('attending')}
        >
          <Text style={[styles.tabText, activeTab === 'attending' && styles.activeTabText]}>
            Attending
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'organizing' && styles.activeTab]}
          onPress={() => setActiveTab('organizing')}
        >
          <Text style={[styles.tabText, activeTab === 'organizing' && styles.activeTabText]}>
            Organizing
          </Text>
        </TouchableOpacity>
      </View>

      {filteredEvents.length === 0 ? (
        <View style={styles.emptyState}>
          <FontAwesome name="calendar-o" size={64} color="#ccc" />
          <Text style={styles.emptyStateText}>
            {activeTab === 'attending'
              ? "You're not attending any events yet"
              : "You're not organizing any events yet"}
          </Text>
          {activeTab === 'organizing' && (
            <TouchableOpacity
              style={styles.createButton}
              onPress={() => navigation.navigate('CreateEvent', {})}
            >
              <Text style={styles.createButtonText}>Create an Event</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <FlatList
          data={filteredEvents}
          renderItem={renderEventCard}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.eventsList}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#6200ee',
  },
  tabText: {
    fontSize: 16,
    color: '#666',
  },
  activeTabText: {
    fontWeight: 'bold',
    color: '#6200ee',
  },
  eventsList: {
    padding: 16,
  },
  eventCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 8,
  },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  eventDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  eventInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 6,
  },
  eventInfoText: {
    fontSize: 14,
    color: '#666',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 24,
  },
  createButton: {
    backgroundColor: '#6200ee',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
  },
  createButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default MyEventsScreen;