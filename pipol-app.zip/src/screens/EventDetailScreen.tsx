import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/RootNavigator';
import { Ionicons, FontAwesome } from '@expo/vector-icons';

type EventDetailScreenRouteProp = RouteProp<RootStackParamList, 'EventDetail'>;

// Sample event data (in a real app, this would come from a database)
const sampleEvents = {
  '1': {
    id: '1',
    title: 'Beach Cleanup',
    description: 'Join us in cleaning up the beach. We'll provide all the necessary equipment. Let\'s make a difference together!',
    category: 'Environment',
    price: 0,
    latitude: 37.78825,
    longitude: -122.4324,
    date_time: '2025-05-15T10:00:00Z',
    organizer: 'Green Earth Association',
    attendees: 12,
  },
  '2': {
    id: '2',
    title: 'Yoga in the Park',
    description: 'Morning yoga session for all levels. Please bring your own mat and water bottle. We\'ll enjoy a refreshing session in nature.',
    category: 'Fitness',
    price: 5,
    latitude: 37.78525,
    longitude: -122.4354,
    date_time: '2025-05-20T08:30:00Z',
    organizer: 'Urban Wellness',
    attendees: 8,
  },
};

const EventDetailScreen = () => {
  const route = useRoute<EventDetailScreenRouteProp>();
  const navigation = useNavigation();
  const { eventId } = route.params;
  const [joining, setJoining] = useState(false);

  // In a real app, we would fetch this data from the API
  const event = sampleEvents[eventId as keyof typeof sampleEvents];

  if (!event) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Event not found</Text>
      </View>
    );
  }

  const handleJoinEvent = () => {
    setJoining(true);
    
    // Simulate API call
    setTimeout(() => {
      setJoining(false);
      if (event.price > 0) {
        // In a real app, we would redirect to Stripe payment
        Alert.alert(
          'Payment Required',
          `This event costs $${event.price}. In a full implementation, you would be redirected to Stripe for payment.`
        );
      } else {
        Alert.alert(
          'Success',
          'You have successfully joined this event!',
          [{ text: 'OK' }]
        );
      }
    }, 1000);
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{event.title}</Text>
        <View style={styles.categoryContainer}>
          <Text style={styles.category}>{event.category}</Text>
        </View>
      </View>

      <View style={styles.card}>
        <View style={styles.section}>
          <View style={styles.infoRow}>
            <FontAwesome name="calendar" size={20} color="#6200ee" style={styles.icon} />
            <Text style={styles.infoText}>{formatDate(event.date_time)}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <FontAwesome name="map-marker" size={20} color="#6200ee" style={styles.icon} />
            <Text style={styles.infoText}>
              {`Latitude: ${event.latitude.toFixed(4)}, Longitude: ${event.longitude.toFixed(4)}`}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <FontAwesome name="user" size={20} color="#6200ee" style={styles.icon} />
            <Text style={styles.infoText}>Organized by: {event.organizer}</Text>
          </View>

          <View style={styles.infoRow}>
            <FontAwesome name="users" size={20} color="#6200ee" style={styles.icon} />
            <Text style={styles.infoText}>{event.attendees} people attending</Text>
          </View>

          <View style={styles.infoRow}>
            <FontAwesome name="money" size={20} color="#6200ee" style={styles.icon} />
            <Text style={styles.infoText}>
              {event.price === 0 ? 'Free' : `$${event.price}`}
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Description</Text>
          <Text style={styles.description}>{event.description}</Text>
        </View>

        <TouchableOpacity
          style={styles.joinButton}
          onPress={handleJoinEvent}
          disabled={joining}
        >
          {joining ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <FontAwesome name="check-circle" size={20} color="#fff" style={{ marginRight: 8 }} />
              <Text style={styles.joinButtonText}>
                {event.price === 0 ? 'Join Event' : `Join Event - $${event.price}`}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  errorText: {
    fontSize: 16,
    color: 'red',
    textAlign: 'center',
    padding: 20,
  },
  header: {
    backgroundColor: '#6200ee',
    padding: 20,
    paddingTop: 40,
    paddingBottom: 30,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  categoryContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  category: {
    color: '#fff',
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    margin: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  description: {
    fontSize: 16,
    color: '#555',
    lineHeight: 24,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  icon: {
    marginRight: 12,
    width: 20,
    textAlign: 'center',
  },
  infoText: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  joinButton: {
    backgroundColor: '#6200ee',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
  },
  joinButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default EventDetailScreen;