import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Image, 
  Alert, 
  Switch, 
  ScrollView,
  ActivityIndicator,
  FlatList
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { FontAwesome } from '@expo/vector-icons';
import { 
  supabase, 
  getCurrentUser, 
  getUserCreatedEvents, 
  getUserAttendingEvents, 
  signOut, 
  User as SupabaseUser,
  Event as SupabaseEvent
} from '../services/supabaseClient';

// Adapt Supabase types to our component types
type User = {
  id: string;
  name: string;
  username: string;
  email: string;
  createdAt: string;
  bio: string | null;
  avatar: string | null;
};

type Event = {
  id: string;
  title: string;
  description: string;
  category: string;
  date: string;
  latitude: number;
  longitude: number;
  locationName: string;
  price: number;
};

const ProfileScreen = () => {
  const navigation = useNavigation();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationShareEnabled, setLocationShareEnabled] = useState(true);
  
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [createdEvents, setCreatedEvents] = useState<Event[]>([]);
  const [attendingEvents, setAttendingEvents] = useState<Event[]>([]);
  
  useEffect(() => {
    fetchUserData();
    fetchUserEvents();
  }, []);
  
  const fetchUserData = async () => {
    try {
      setIsLoading(true);
      
      // Get current user from Supabase
      const userData = await getCurrentUser();
      
      if (userData) {
        // Map Supabase user to our User type
        setUser({
          id: userData.id,
          name: userData.name,
          username: userData.username,
          email: userData.email,
          createdAt: userData.created_at,
          bio: userData.bio,
          avatar: userData.avatar_url
        });
      } else {
        // Not logged in, redirect to login
        navigation.navigate('Auth');
      }
      
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching user data:', error);
      setIsLoading(false);
      Alert.alert('Error', 'Failed to load user data. Please try again.');
    }
  };
  
  const fetchUserEvents = async () => {
    try {
      // Get events created by the user
      const createdEventsData = await getUserCreatedEvents();
      
      // Map Supabase events to our Event type
      const mappedCreatedEvents = createdEventsData.map(event => ({
        id: event.id,
        title: event.title,
        description: event.description,
        category: event.category,
        date: event.date_time,
        latitude: event.latitude,
        longitude: event.longitude,
        locationName: event.location_name,
        price: event.price
      }));
      
      setCreatedEvents(mappedCreatedEvents);
      
      // Get events the user is attending
      const attendingEventsData = await getUserAttendingEvents();
      
      // Map Supabase events to our Event type
      const mappedAttendingEvents = attendingEventsData.map(event => ({
        id: event.id,
        title: event.title,
        description: event.description,
        category: event.category,
        date: event.date_time,
        latitude: event.latitude,
        longitude: event.longitude,
        locationName: event.location_name,
        price: event.price
      }));
      
      setAttendingEvents(mappedAttendingEvents);
    } catch (error) {
      console.error('Error fetching user events:', error);
      Alert.alert('Error', 'Failed to load user events. Please try again.');
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Log Out',
      'Are you sure you want to log out?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Log Out',
          onPress: async () => {
            try {
              // Sign out using Supabase
              await signOut();
              
              // Show success message
              Alert.alert('Logged Out', 'You have been logged out successfully');
              
              // Navigate to login screen
              navigation.navigate('Auth');
            } catch (error) {
              console.error('Error signing out:', error);
              Alert.alert('Error', 'Failed to sign out. Please try again.');
            }
          },
        },
      ]
    );
  };

  // Event card component to be used in the list
  const EventCard = ({ event }: { event: Event }) => {
    const formattedDate = new Date(event.date).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    const isPaid = event.price > 0;
    
    return (
      <TouchableOpacity 
        style={styles.eventCard}
        onPress={() => navigation.navigate('EventDetail', { eventId: event.id })}
      >
        <View style={styles.eventHeader}>
          <Text style={styles.eventTitle}>{event.title}</Text>
          <View style={[
            styles.eventPriceTag,
            isPaid ? styles.paidEvent : styles.freeEvent
          ]}>
            <Text style={styles.eventPriceText}>
              {isPaid ? `$${event.price}` : 'Free'}
            </Text>
          </View>
        </View>
        
        <Text style={styles.eventLocation}>{event.locationName}</Text>
        <Text style={styles.eventDate}>{formattedDate}</Text>
        
        <View style={styles.eventCategory}>
          <Text style={styles.eventCategoryText}>{event.category}</Text>
        </View>
      </TouchableOpacity>
    );
  };
  
  // Loading screen
  if (isLoading || !user) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6200ee" />
        <Text style={styles.loadingText}>Loading profile...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.profileImageContainer}>
          {/* Using a placeholder for the profile image */}
          <View style={styles.profileImage}>
            <Text style={styles.profileInitials}>
              {user.name.split(' ').map(name => name[0]).join('')}
            </Text>
          </View>
        </View>
        <Text style={styles.name}>{user.name}</Text>
        <Text style={styles.email}>{user.email}</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{attendingEvents.length}</Text>
          <Text style={styles.statLabel}>Events Attending</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{createdEvents.length}</Text>
          <Text style={styles.statLabel}>Events Organized</Text>
        </View>
      </View>
      
      {/* User's events section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>My Events</Text>
        
        {createdEvents.length > 0 ? (
          <>
            <Text style={styles.subsectionTitle}>Events I'm Organizing</Text>
            {createdEvents.map(event => (
              <EventCard key={`created-${event.id}`} event={event} />
            ))}
          </>
        ) : (
          <Text style={styles.emptyStateText}>You haven't created any events yet.</Text>
        )}
        
        {attendingEvents.length > 0 ? (
          <>
            <Text style={styles.subsectionTitle}>Events I'm Attending</Text>
            {attendingEvents.map(event => (
              <EventCard key={`attending-${event.id}`} event={event} />
            ))}
          </>
        ) : (
          <Text style={styles.emptyStateText}>You're not attending any events yet.</Text>
        )}
        
        <TouchableOpacity 
          style={styles.createEventButton}
          onPress={() => navigation.navigate('CreateEvent', {})}
        >
          <FontAwesome name="plus" size={16} color="#fff" style={styles.createEventIcon} />
          <Text style={styles.createEventText}>Create New Event</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        
        <TouchableOpacity style={styles.menuItem}>
          <FontAwesome name="user" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Edit Profile</Text>
          <FontAwesome name="chevron-right" size={16} color="#ccc" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <FontAwesome name="lock" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Change Password</Text>
          <FontAwesome name="chevron-right" size={16} color="#ccc" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <FontAwesome name="credit-card" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Payment Methods</Text>
          <FontAwesome name="chevron-right" size={16} color="#ccc" />
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferences</Text>
        
        <View style={styles.menuItem}>
          <FontAwesome name="bell" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Notifications</Text>
          <Switch
            value={notificationsEnabled}
            onValueChange={setNotificationsEnabled}
            trackColor={{ false: '#ccc', true: '#a880f7' }}
            thumbColor={notificationsEnabled ? '#6200ee' : '#f4f3f4'}
          />
        </View>
        
        <View style={styles.menuItem}>
          <FontAwesome name="map-marker" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Share Location</Text>
          <Switch
            value={locationShareEnabled}
            onValueChange={setLocationShareEnabled}
            trackColor={{ false: '#ccc', true: '#a880f7' }}
            thumbColor={locationShareEnabled ? '#6200ee' : '#f4f3f4'}
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>More</Text>
        
        <TouchableOpacity style={styles.menuItem}>
          <FontAwesome name="question-circle" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Help & Support</Text>
          <FontAwesome name="chevron-right" size={16} color="#ccc" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <FontAwesome name="shield" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Privacy Policy</Text>
          <FontAwesome name="chevron-right" size={16} color="#ccc" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <FontAwesome name="file-text" size={20} color="#6200ee" style={styles.menuIcon} />
          <Text style={styles.menuText}>Terms of Service</Text>
          <FontAwesome name="chevron-right" size={16} color="#ccc" />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Member since {new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
        </Text>
        <Text style={styles.footerText}>Pipol App v1.0.0</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#6200ee',
    paddingTop: 30,
    paddingBottom: 30,
    alignItems: 'center',
  },
  profileImageContainer: {
    marginBottom: 16,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitials: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#6200ee',
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginTop: 1,
    paddingVertical: 16,
    marginBottom: 16,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6200ee',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
  },
  divider: {
    width: 1,
    backgroundColor: '#eee',
    height: '80%',
    alignSelf: 'center',
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 8,
    marginHorizontal: 16,
    marginBottom: 16,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginVertical: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  menuIcon: {
    marginRight: 16,
    width: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuText: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  logoutButton: {
    backgroundColor: '#f0f0f0',
    paddingVertical: 12,
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 8,
  },
  logoutText: {
    fontSize: 16,
    color: '#ff3b30',
    fontWeight: 'bold',
  },
  footer: {
    alignItems: 'center',
    padding: 16,
    paddingBottom: 32,
  },
  footerText: {
    fontSize: 12,
    color: '#999',
    marginBottom: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  subsectionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#666',
    marginTop: 16,
    marginBottom: 8,
  },
  eventCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: '#eee',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  eventLocation: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  eventDate: {
    fontSize: 12,
    color: '#888',
    marginBottom: 8,
  },
  eventCategory: {
    alignSelf: 'flex-start',
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  eventCategoryText: {
    fontSize: 12,
    color: '#666',
  },
  eventPriceTag: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  freeEvent: {
    backgroundColor: '#e0f7e0',
  },
  paidEvent: {
    backgroundColor: '#e0e0ff',
  },
  eventPriceText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#333',
  },
  emptyStateText: {
    fontSize: 14,
    color: '#999',
    fontStyle: 'italic',
    textAlign: 'center',
    marginVertical: 20,
  },
  createEventButton: {
    backgroundColor: '#6200ee',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  createEventIcon: {
    marginRight: 8,
  },
  createEventText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default ProfileScreen;